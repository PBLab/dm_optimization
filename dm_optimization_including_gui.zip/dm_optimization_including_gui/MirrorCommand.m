function MirrorCommand(zernikeVector,nZern,mirrorMatrix)
% Sends a command to the mirror
zeroVec = zeros( 1, nZern );
for n = 1:nZern
    zeroVec(n)=zernikeVector(n);
    zeroVec * mirrorMatrix;  
    zeroVec(n) = 0;      
end
    
end