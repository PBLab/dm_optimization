function updateMirror(oldParams, newParams,oldZernike,olderZernike)
% Following a comparison of the old and new image parameters,
% decides on the best course of action for the mirror.
    
    newZernike = testIfHigher(oldParams, newParams,oldZernike,olderZernike);
    % Import mirror data
    Z2C=importdata('BAX278-Z2C.mat');
    % Send command to mirror
    MirrorCommand(newZernike,30,Z2C);
    fprintf("Command sent")
    fprintf('\n');
    % Update zernike vectors
    save('olderZernike.mat','oldZernike')
    save('oldZernike.mat','newZernike')
end