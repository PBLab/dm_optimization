oldParams = zeros(1);
olderZernike=zeros(1,30);
oldZernike=GenerateRandVec(30,-10,0.1,10);
for iteration = 1:100
    newParams = pipeline(oldParams,oldZernike,olderZernike);
    fprintf("The new params are: %s", newParams);
    graphParams(newParams(iteration, :));
    oldParams = newParams;
end