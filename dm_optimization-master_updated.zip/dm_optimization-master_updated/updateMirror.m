function updateMirror(oldParams, newParams,oldZernike,olderZernike)
% Following a comparison of the old and new image parameters,
% decides on the best course of action for the mirror.
    
    newZernike = testIfHigher(oldParams, newParams,oldZernike,olderZernike);
    Z2C=importdata('BAX278-Z2C.mat');
    MirrorCommand(newZernike,30,Z2C);    
    olderZernike=oldZernike;
    oldZernike=newZernike;

end