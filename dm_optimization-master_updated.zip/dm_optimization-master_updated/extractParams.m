function params = extractParams(img)
% For a given image, calculates the mean value of all pixels in the image.

params = mean(img(:));

end